package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ModelTest {

    @Test
    void testBox() {
        Model M1= new Model();
        assertEquals(true, M1.addWorld("w1"));
        assertEquals(false, M1.addWorld("w1"));
        assertEquals(true, M1.addAgent("Alice"));
        assertEquals(false, M1.addAgent("Alice"));
        M1.getAgent("Alice");
        assertEquals(true, M1.addWorld("w2"));
        assertEquals(true, M1.addAtom("p"));
        M1.setTrueAt("p", "w1");
        assertEquals(true, M1.addRelation("Alice", "w1", "w2"));
        assertEquals(true, M1.valuation("p", "w1"));
        M1.toggleTruthAt("p", "w1");
        assertEquals(false, M1.valuation("p", "w1"));

        String s1= "w1";
        String s2= "w1";
        assertEquals(true, s1.contentEquals(s2));
    }

}
